// const overBtn = document.querySelectorAll(".overBtn");
// const outlineBtn  = document.querySelectorAll(".outlineBtn");
//
//
// overBtn.forEach((elem)=>{
//     elem.style.width = "45%"
// })
// outlineBtn.forEach((elem)=>{
//     elem.style.top = "50%"
//     elem.style.left = "calc(50% - 40px)";
// })
